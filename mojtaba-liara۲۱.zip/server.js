// ابزارآلات مجتبی — سرور بدون وابستگی خارجی (Node 22+، SQLite داخلی)
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const PORT=+process.env.PORT||3000, DATA=process.env.DATA_DIR||path.join(__dirname,'data');
const SECURE=process.env.COOKIE_SECURE==='1';
fs.mkdirSync(path.join(DATA,'uploads'),{recursive:true});
const db=new DatabaseSync(path.join(DATA,'shop.db'));
db.exec(`PRAGMA journal_mode=WAL;PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT UNIQUE NOT NULL,city TEXT NOT NULL,address TEXT NOT NULL,pass_hash TEXT NOT NULL,username TEXT,recovery_hash TEXT,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT NOT NULL,brand TEXT DEFAULT '',code TEXT DEFAULT '',category TEXT DEFAULT 'سایر',description TEXT DEFAULT '',image TEXT DEFAULT '',buy_price INTEGER DEFAULT 0,sell_price INTEGER NOT NULL,stock INTEGER DEFAULT 0,discount INTEGER DEFAULT 0,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS price_history(id INTEGER PRIMARY KEY,product_id INTEGER,old_price INTEGER,new_price INTEGER,batch TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,code TEXT UNIQUE,customer_id INTEGER NOT NULL,status TEXT DEFAULT 'pending',total INTEGER,note TEXT DEFAULT '',admin_note TEXT DEFAULT '',cust_name TEXT,cust_phone TEXT,cust_city TEXT,cust_address TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,name TEXT,unit_price INTEGER,qty INTEGER,line_total INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS site_settings(key TEXT PRIMARY KEY,value TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS purchase_invoices(id INTEGER PRIMARY KEY,seller TEXT,date TEXT,total INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS purchase_invoice_items(id INTEGER PRIMARY KEY,invoice_id INTEGER,product_id INTEGER,name TEXT,qty INTEGER,unit_price INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL,customer_id INTEGER NOT NULL,amount INTEGER NOT NULL,ref TEXT DEFAULT '',method TEXT DEFAULT 'card',status TEXT DEFAULT 'pending',authority TEXT,gateway_ref TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS product_sources(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL,seller TEXT,date TEXT,qty INTEGER,unit_price INTEGER,source TEXT DEFAULT 'manual',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,role TEXT,customer_id INTEGER,expires INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
for(const c of['username TEXT','recovery_hash TEXT']){try{db.exec('ALTER TABLE customers ADD COLUMN '+c)}catch{}}
try{db.exec('ALTER TABLE purchase_invoices ADD COLUMN image TEXT')}catch{}
for(const c of['ALTER TABLE products ADD COLUMN discount INTEGER DEFAULT 0','ALTER TABLE order_items ADD COLUMN discount INTEGER DEFAULT 0']){try{db.exec(c)}catch{}}
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS ux_cust_username ON customers(username)');
try{db.exec("DELETE FROM sessions WHERE expires<"+Date.now())}catch{}
const q=(s,...a)=>db.prepare(s).all(...a), one=(s,...a)=>db.prepare(s).get(...a), run=(s,...a)=>db.prepare(s).run(...a);
const now=()=>new Date().toISOString().replace('T',' ').slice(0,19);
const tx=fn=>{db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}};
// ---- تنظیمات و رمز مدیر
const DEF={shop_name:'ابزارآلات مجتبی',address:'ساوه، خیابان هلالی (اسدی)، جنب اسدی ۴',phone:'09100811101'};
for(const[k,v]of Object.entries(DEF))run('INSERT OR IGNORE INTO site_settings(key,value) VALUES(?,?)',k,v);
const getSet=k=>(one('SELECT value FROM site_settings WHERE key=?',k)||{}).value;
const setSet=(k,v)=>run('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=?',k,v,now());
// ---- رمزنگاری
const hash=p=>{const s=crypto.randomBytes(16).toString('hex');return s+':'+crypto.scryptSync(p,s,64).toString('hex')};
const check=(p,h)=>{const[s,x]=String(h).split(':');if(!s||!x)return false;const y=crypto.scryptSync(p,s,64);const b=Buffer.from(x,'hex');return b.length===y.length&&crypto.timingSafeEqual(y,b)};
const SETUP_CODE=process.env.ADMIN_SETUP_CODE||crypto.randomBytes(4).toString('hex');
if(!getSet('admin_user')&&!process.env.ADMIN_SETUP_CODE)console.log('کد راه‌اندازی مدیر (برای ساخت حساب مدیر):',SETUP_CODE);
const norm=w=>fd(String(w||'')).trim().toLowerCase().replace(/\s+/g,' ');
const sha=t=>crypto.createHash('sha256').update(t).digest('hex');
function newSession(role,cid){const t=crypto.randomBytes(32).toString('hex');run('INSERT INTO sessions(token_hash,role,customer_id,expires) VALUES(?,?,?,?)',sha(t),role,cid||null,Date.now()+7*864e5);return t}
const cookie=(t,age)=>`sid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${age}${SECURE?'; Secure':''}`;
function auth(req){const m=/(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie||'');if(!m)return null;
 const s=one('SELECT * FROM sessions WHERE token_hash=? AND expires>?',sha(m[1]),Date.now());if(!s)return null;
 if(s.role==='customer'){const c=one('SELECT * FROM customers WHERE id=? AND active=1',s.customer_id);if(!c)return null;return{role:'customer',c,tok:sha(m[1])}}
 return{role:'admin',tok:sha(m[1])}}
const tries=new Map();function limited(k){const n=tries.get(k)||{c:0,t:Date.now()};if(Date.now()-n.t>9e5){n.c=0;n.t=Date.now()}tries.set(k,n);return n.c>=8}
const fail=k=>{const n=tries.get(k);if(n)n.c++};
// ---- اعتبارسنجی
const fd=s=>String(s??'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const str=(v,max=200)=>String(v??'').trim().slice(0,max);
const int=(v,min=0,max=1e12)=>{const n=Number(fd(v));if(!Number.isInteger(n)||n<min||n>max)throw new E(400,'مقدار عددی نامعتبر است');return n};
class E extends Error{constructor(c,m){super(m);this.code=c}}
const phone=v=>{const p=fd(str(v,20)).replace(/\s/g,'');if(!/^09\d{9}$/.test(p))throw new E(400,'شماره موبایل باید به شکل 09123456789 باشد');return p};
const pass=v=>{v=String(v||'');if(v.length<8||v.length>100)throw new E(400,'رمز عبور باید حداقل ۸ کاراکتر باشد');return v};
const uname=v=>{const u=fd(str(v,40)).toLowerCase();if(!/^[a-z0-9_.]{3,30}$/.test(u))throw new E(400,'نام کاربری باید ۳ تا ۳۰ حرف انگلیسی، عدد، _ یا . باشد');return u};
const rec=v=>{const w=norm(v);if(w.length<3||w.length>60)throw new E(400,'کلمه بازیابی باید حداقل ۳ حرف باشد');return w};
const CATS=['قفل','سیلندر','دستگیره','لولا','یراق کابینت','ابزار نصب','سایر'];
// ---- تصویر
const sniff=buf=>buf[0]===0xff&&buf[1]===0xd8?'jpg':buf.slice(1,4).toString()==='PNG'?'png':(buf.slice(0,4).toString()==='RIFF'&&buf.slice(8,12).toString()==='WEBP')?'webp':null;
function saveImage(b){const mime=str(b.mime,30),buf=Buffer.from(String(b.data||''),'base64');
 if(buf.length<100||buf.length>2*1024*1024)throw new E(400,'حجم عکس باید کمتر از ۲ مگابایت باشد');
 const ext=sniff(buf);
 if(!ext||!/^image\//.test(mime))throw new E(400,'فرمت عکس مجاز نیست (jpg/png/webp)');
 const name=crypto.randomUUID()+'.'+ext;fs.writeFileSync(path.join(DATA,'uploads',name),buf);return '/uploads/'+name}
// ---- سفارش و موجودی
const reserved=s=>s==='approved'||s==='completed';
const ST=['pending','approved','rejected','completed'];
function changeStatus(id,to,note){return tx(()=>{const o=one('SELECT * FROM orders WHERE id=?',id);if(!o)throw new E(404,'سفارش پیدا نشد');
 if(!ST.includes(to))throw new E(400,'وضعیت نامعتبر');const items=q('SELECT * FROM order_items WHERE order_id=?',id);
 if(!reserved(o.status)&&reserved(to)){for(const i of items){const p=one('SELECT stock,name FROM products WHERE id=?',i.product_id);if(!p||p.stock<i.qty)throw new E(409,`موجودی «${i.name}» کافی نیست (موجودی: ${p?p.stock:0}، سفارش: ${i.qty})`)}
  for(const i of items)run('UPDATE products SET stock=stock-?,updated_at=? WHERE id=?',i.qty,now(),i.product_id)}
 else if(reserved(o.status)&&!reserved(to))for(const i of items)run('UPDATE products SET stock=stock+?,updated_at=? WHERE id=?',i.qty,now(),i.product_id);
 run('UPDATE orders SET status=?,admin_note=?,updated_at=? WHERE id=?',to,note===undefined?o.admin_note:str(note,500),now(),id);return one('SELECT * FROM orders WHERE id=?',id)})}
const fp=p=>Math.round(p.sell_price*(100-(p.discount||0))/100);
const orderFull=o=>{const pay=q('SELECT id,amount,ref,method,status,created_at FROM payments WHERE order_id=? ORDER BY id',o.id);return{...o,items:q('SELECT product_id,name,unit_price,qty,line_total,discount FROM order_items WHERE order_id=?',o.id),payments:pay,paid:pay.filter(x=>x.status==='confirmed'||x.status==='paid').reduce((s,x)=>s+x.amount,0)}};
const pubProd=p=>{const{buy_price,...r}=p;return{...r,final_price:fp(p)}};
// ---- مسیرها
const routes=[];const R=(m,p,role,fn)=>routes.push({m,re:new RegExp('^'+p.replace(/:id/g,'(\\d+)')+'$'),role,fn});
R('GET','/api/settings',null,r=>({shop_name:getSet('shop_name'),address:getSet('address'),phone:getSet('phone'),categories:CATS,...(r.a?{bank_card:getSet('bank_card')||'',bank_account:getSet('bank_account')||'',bank_owner:getSet('bank_owner')||''}:{})}));
R('POST','/api/register',null,(r,b,res)=>{const k='r'+r.ip;if(limited(k))throw new E(429,'تلاش زیاد؛ کمی بعد دوباره امتحان کنید');
 const d={name:str(b.name,80),phone:phone(b.phone),city:str(b.city,60),address:str(b.address,400),username:uname(b.username)};
 if(!d.name||!d.city||!d.address)throw new E(400,'همه اطلاعات الزامی است');const h=hash(pass(b.password)),rh=hash(rec(b.recovery));
 if(one('SELECT 1 FROM customers WHERE phone=?',d.phone)){fail(k);throw new E(409,'با این شماره قبلاً ثبت‌نام شده است')}
 if(one('SELECT 1 FROM customers WHERE username=?',d.username)){fail(k);throw new E(409,'این نام کاربری قبلاً گرفته شده است')}
 const id=Number(run('INSERT INTO customers(name,phone,city,address,pass_hash,username,recovery_hash) VALUES(?,?,?,?,?,?,?)',d.name,d.phone,d.city,d.address,h,d.username,rh).lastInsertRowid);
 res.cookie=cookie(newSession('customer',id),604800);return{ok:true}});
R('POST','/api/login',null,(r,b,res)=>{const p=fd(str(b.username||b.phone,40)).toLowerCase(),k='l'+r.ip+p;if(limited(k))throw new E(429,'تلاش زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید');
 const c=one('SELECT * FROM customers WHERE (username=? OR phone=?) AND active=1',p,p);if(!c||!check(String(b.password||''),c.pass_hash)){fail(k);throw new E(401,'نام کاربری یا رمز اشتباه است')}
 res.cookie=cookie(newSession('customer',c.id),604800);return{ok:true}});
R('POST','/api/recover',null,(r,b)=>{const p=fd(str(b.username,40)).toLowerCase(),k='rc'+r.ip+p;if(limited(k))throw new E(429,'تلاش زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید');
 const c=one('SELECT * FROM customers WHERE (username=? OR phone=?) AND active=1',p,p);
 if(!c||!c.recovery_hash||!check(norm(b.recovery),c.recovery_hash)){fail(k);throw new E(401,'اطلاعات بازیابی اشتباه است')}
 run('UPDATE customers SET pass_hash=?,updated_at=? WHERE id=?',hash(pass(b.next)),now(),c.id);run('DELETE FROM sessions WHERE customer_id=?',c.id);return{ok:true}});
R('GET','/api/admin/status',null,()=>({setup:!getSet('admin_user')}));
R('POST','/api/admin/setup',null,(r,b,res)=>{const k='s'+r.ip;if(getSet('admin_user'))throw new E(409,'حساب مدیر قبلاً ساخته شده است');if(limited(k))throw new E(429,'تلاش زیاد');
 if(str(b.code,40)!==SETUP_CODE){fail(k);throw new E(403,'کد راه‌اندازی اشتباه است')}
 const u=uname(b.username),h=hash(pass(b.password)),rh=hash(rec(b.recovery));setSet('admin_user',u);setSet('admin_hash',h);setSet('admin_recovery',rh);
 res.cookie=cookie(newSession('admin'),604800);return{ok:true}});
R('POST','/api/admin/login',null,(r,b,res)=>{const k='a'+r.ip;if(limited(k))throw new E(429,'تلاش زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید');
 const ok=getSet('admin_user')&&fd(str(b.username,40)).toLowerCase()===getSet('admin_user')&&check(String(b.password||''),getSet('admin_hash'));
 if(!ok){fail(k);throw new E(401,'نام کاربری یا رمز اشتباه است')}res.cookie=cookie(newSession('admin'),604800);return{ok:true}});
R('POST','/api/admin/recover',null,(r,b)=>{const k='ar'+r.ip;if(limited(k))throw new E(429,'تلاش زیاد؛ ۱۵ دقیقه بعد دوباره امتحان کنید');
 const ok=getSet('admin_user')&&fd(str(b.username,40)).toLowerCase()===getSet('admin_user')&&check(norm(b.recovery),getSet('admin_recovery'));
 if(!ok){fail(k);throw new E(401,'اطلاعات بازیابی اشتباه است')}setSet('admin_hash',hash(pass(b.next)));run("DELETE FROM sessions WHERE role='admin'");return{ok:true}});
R('POST','/api/logout',null,(r,b,res)=>{if(r.a)run('DELETE FROM sessions WHERE token_hash=?',r.a.tok);res.cookie=cookie('',0);return{ok:true}});
R('GET','/api/me',null,r=>r.a?(r.a.role==='admin'?{role:'admin'}:{role:'customer',username:r.a.c.username,name:r.a.c.name,phone:r.a.c.phone,city:r.a.c.city,address:r.a.c.address}):{role:null});
R('PUT','/api/me','customer',(r,b)=>{run('UPDATE customers SET name=?,city=?,address=?,updated_at=? WHERE id=?',str(b.name,80),str(b.city,60),str(b.address,400),now(),r.a.c.id);return{ok:true}});
R('POST','/api/me/password','customer',(r,b)=>{if(!check(String(b.current||''),r.a.c.pass_hash))throw new E(403,'رمز فعلی اشتباه است');
 const h=hash(pass(b.next)),rh=b.recovery?hash(rec(b.recovery)):null;run('UPDATE customers SET pass_hash=?,updated_at=? WHERE id=?',h,now(),r.a.c.id);if(rh)run('UPDATE customers SET recovery_hash=? WHERE id=?',rh,r.a.c.id);return{ok:true}});
R('GET','/api/products','any',r=>{const a=q('SELECT * FROM products'+(r.a.role==='admin'?'':' WHERE active=1')+' ORDER BY id DESC');return r.a.role==='admin'?a.map(p=>({...p,final_price:fp(p)})):a.map(pubProd)});
const prodBody=(b,old={})=>({name:str(b.name,150)||(()=>{throw new E(400,'نام محصول الزامی است')})(),brand:str(b.brand,80),code:str(b.code,60),category:CATS.includes(b.category)?b.category:'سایر',description:str(b.description,1500),
 buy_price:int(b.buy_price??0),sell_price:int(b.sell_price,1),stock:int(b.stock??0)});
const DATE_RE=/^\d{4}-\d{2}-\d{2}$/;
const addSource=(pid,b,src='manual')=>{const seller=str(b.seller,100),date=DATE_RE.test(str(b.buy_date??b.date,12))?str(b.buy_date??b.date,12):'';if(!seller&&!date)return false;
 const qty=b.qty?int(b.qty,1,1e6):null,up=b.unit_price?int(b.unit_price,1):null;const l=one("SELECT seller,date FROM product_sources WHERE product_id=? AND source='manual' ORDER BY id DESC",pid);
 if(src==='manual'&&l&&(l.seller||'')===seller&&(l.date||'')===date&&!qty&&!up)return false;
 run('INSERT INTO product_sources(product_id,seller,date,qty,unit_price,source) VALUES(?,?,?,?,?,?)',pid,seller||null,date||null,qty,up,src);return true};
R('GET','/api/admin/products/:id/history','admin',r=>q('SELECT id,seller,date,qty,unit_price,source,created_at FROM product_sources WHERE product_id=? ORDER BY COALESCE(date,created_at) DESC,id DESC',+r.p[0]));
R('POST','/api/admin/products/:id/history','admin',(r,b)=>{const id=+r.p[0];if(!one('SELECT 1 FROM products WHERE id=?',id))throw new E(404,'محصول پیدا نشد');if(!addSource(id,b))throw new E(400,'فروشنده یا تاریخ را وارد کنید');return{ok:true}});
R('POST','/api/admin/products','admin',(r,b)=>{const d=prodBody(b),img=b.image?saveImage(b.image):'';const id=Number(run('INSERT INTO products(name,brand,code,category,description,buy_price,sell_price,stock) VALUES(?,?,?,?,?,?,?,?)',d.name,d.brand,d.code,d.category,d.description,d.buy_price,d.sell_price,d.stock).lastInsertRowid);
 if(img)run('UPDATE products SET image=? WHERE id=?',img,id);addSource(id,b);return one('SELECT * FROM products WHERE id=?',id)});
R('PUT','/api/admin/products/:id','admin',(r,b)=>{const id=+r.p[0],o=one('SELECT * FROM products WHERE id=?',id);if(!o)throw new E(404,'محصول پیدا نشد');const d=prodBody(b),img=b.image?saveImage(b.image):'';
 if(d.sell_price!==o.sell_price)run('INSERT INTO price_history(product_id,old_price,new_price,batch) VALUES(?,?,?,?)',id,o.sell_price,d.sell_price,'manual');
 run('UPDATE products SET name=?,brand=?,code=?,category=?,description=?,buy_price=?,sell_price=?,stock=?,active=?,updated_at=? WHERE id=?',d.name,d.brand,d.code,d.category,d.description,d.buy_price,d.sell_price,d.stock,b.active===false?0:1,now(),id);
 if(img)run('UPDATE products SET image=? WHERE id=?',img,id);addSource(id,b);return one('SELECT * FROM products WHERE id=?',id)});
R('DELETE','/api/admin/products/:id','admin',r=>{run('UPDATE products SET active=0,updated_at=? WHERE id=?',now(),+r.p[0]);return{ok:true}});
R('POST','/api/admin/prices','admin',(r,b)=>{const v=Number(fd(b.value));if(!isFinite(v)||v===0)throw new E(400,'مقدار نامعتبر');const rnd=[1,1000,10000].includes(+b.round)?+b.round:1;
 let list=q('SELECT * FROM products WHERE active=1');if(b.category)list=list.filter(p=>p.category===b.category);if(Array.isArray(b.ids))list=list.filter(p=>b.ids.map(Number).includes(p.id));
 const rows=list.map(p=>{let n=b.mode==='fix'?p.sell_price+v:p.sell_price*(1+v/100);n=Math.max(1,Math.round(n/rnd)*rnd);return{id:p.id,name:p.name,old:p.sell_price,new:n}}).filter(x=>x.new!==x.old);
 if(b.preview)return{rows};const batch='b'+Date.now();tx(()=>rows.forEach(x=>{run('UPDATE products SET sell_price=?,updated_at=? WHERE id=?',x.new,now(),x.id);run('INSERT INTO price_history(product_id,old_price,new_price,batch) VALUES(?,?,?,?)',x.id,x.old,x.new,batch)}));return{rows,batch}});
R('POST','/api/admin/prices/revert','admin',(r,b)=>{const rows=q('SELECT * FROM price_history WHERE batch=?',str(b.batch,40));if(!rows.length)throw new E(404,'پیدا نشد');
 tx(()=>rows.forEach(x=>run('UPDATE products SET sell_price=?,updated_at=? WHERE id=?',x.old_price,now(),x.product_id)));return{reverted:rows.length}});
R('POST','/api/orders','customer',(r,b)=>{if(!Array.isArray(b.items)||!b.items.length||b.items.length>100)throw new E(400,'سبد خرید خالی است');
 return tx(()=>{let total=0;const lines=b.items.map(i=>{const p=one('SELECT * FROM products WHERE id=? AND active=1',int(i.product_id,1)),n=int(i.qty,1,10000);if(!p)throw new E(400,'محصول نامعتبر');const unit=fp(p),lt=unit*n;total+=lt;return{p,n,lt,unit}});
  const c=r.a.c,code='M'+Date.now().toString(36).toUpperCase()+crypto.randomInt(10,99);
  const id=Number(run('INSERT INTO orders(code,customer_id,total,note,cust_name,cust_phone,cust_city,cust_address) VALUES(?,?,?,?,?,?,?,?)',code,c.id,total,str(b.note,500),c.name,c.phone,c.city,c.address).lastInsertRowid);
  lines.forEach(l=>run('INSERT INTO order_items(order_id,product_id,name,unit_price,qty,line_total,discount) VALUES(?,?,?,?,?,?,?)',id,l.p.id,l.p.name,l.unit,l.n,l.lt,l.p.discount||0));return orderFull(one('SELECT * FROM orders WHERE id=?',id))})});
R('GET','/api/orders','customer',r=>q('SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC',r.a.c.id).map(orderFull));
R('GET','/api/admin/orders','admin',()=>q('SELECT * FROM orders ORDER BY id DESC').map(orderFull));
R('POST','/api/admin/orders/:id/status','admin',(r,b)=>orderFull(changeStatus(+r.p[0],b.status,b.admin_note)));
R('PUT','/api/admin/settings','admin',(r,b)=>{for(const k of['shop_name','address','phone'])if(b[k]!==undefined){const v=str(b[k],300);if(!v)throw new E(400,'مقدار خالی مجاز نیست');setSet(k,v)}for(const k of['bank_card','bank_account','bank_owner'])if(b[k]!==undefined)setSet(k,fd(str(b[k],60)));
 return{ok:true}});
R('POST','/api/admin/password','admin',(r,b)=>{if(!check(String(b.current||''),getSet('admin_hash')))throw new E(403,'رمز فعلی اشتباه است');
 const h=hash(pass(b.next)),rh=b.recovery?hash(rec(b.recovery)):null;setSet('admin_hash',h);if(rh)setSet('admin_recovery',rh);return{ok:true}});
R('POST','/api/admin/username','admin',(r,b)=>{if(!check(String(b.password||''),getSet('admin_hash')))throw new E(403,'رمز فعلی اشتباه است');setSet('admin_user',uname(b.username));return{ok:true}});
R('POST','/api/me/username','customer',(r,b)=>{if(!check(String(b.password||''),r.a.c.pass_hash))throw new E(403,'رمز فعلی اشتباه است');const u=uname(b.username);if(one('SELECT 1 FROM customers WHERE username=? AND id<>?',u,r.a.c.id))throw new E(409,'این نام کاربری قبلاً گرفته شده است');run('UPDATE customers SET username=?,updated_at=? WHERE id=?',u,now(),r.a.c.id);return{ok:true}});
R('GET','/api/admin/backup','admin',(r,b,res)=>{const f=path.join(DATA,'bk-'+crypto.randomBytes(4).toString('hex')+'.db');db.exec(`VACUUM INTO '${f.replace(/'/g,"''")}'`);const buf=fs.readFileSync(f);fs.unlinkSync(f);res.raw={buf,name:'mojtaba-backup-'+new Date().toISOString().slice(0,10)+'.db'};return{}});
R('GET','/api/admin/customers','admin',()=>q('SELECT id,name,phone,city,address,active,created_at,(SELECT COUNT(*) FROM orders o WHERE o.customer_id=customers.id) orders FROM customers ORDER BY id DESC'));
R('POST','/api/admin/discounts','admin',(r,b)=>{const pct=int(b.percent,0,90),ids=(Array.isArray(b.ids)?b.ids:[]).map(Number).filter(Number.isInteger);if(!ids.length)throw new E(400,'محصولی انتخاب نشده است');
 tx(()=>ids.forEach(i=>run('UPDATE products SET discount=?,updated_at=? WHERE id=?',pct,now(),i)));return{updated:ids.length}});
// پرداخت: کارت‌به‌کارت (ثبت اطلاعات واریز توسط مشتری و تأیید مدیر) و درگاه آنلاین زرین‌پال
const myOrder=(r)=>{const o=one('SELECT * FROM orders WHERE id=? AND customer_id=?',+r.p[0],r.a.c.id);if(!o)throw new E(404,'سفارش پیدا نشد');if(o.status==='rejected')throw new E(409,'این سفارش رد شده است');return o};
R('POST','/api/orders/:id/payments','customer',(r,b)=>{const o=myOrder(r);const amount=int(b.amount,1,o.total*2),ref=str(fd(b.ref),60);if(!ref)throw new E(400,'شماره پیگیری واریز را وارد کنید');
 run('INSERT INTO payments(order_id,customer_id,amount,ref,method) VALUES(?,?,?,?,?)',o.id,o.customer_id,amount,ref,'card');return orderFull(one('SELECT * FROM orders WHERE id=?',o.id))});
R('POST','/api/admin/payments/:id/status','admin',(r,b)=>{if(!['confirmed','rejected'].includes(b.status))throw new E(400,'وضعیت نامعتبر');const p=one("SELECT * FROM payments WHERE id=? AND method='card'",+r.p[0]);if(!p)throw new E(404,'پرداخت پیدا نشد');
 run('UPDATE payments SET status=?,updated_at=? WHERE id=?',b.status,now(),p.id);return orderFull(one('SELECT * FROM orders WHERE id=?',p.order_id))});
const ZP=()=>process.env.ZARINPAL_BASE||'https://api.zarinpal.com';
R('POST','/api/orders/:id/pay-online','customer',async(r)=>{const mid=process.env.ZARINPAL_MERCHANT_ID,pubUrl=process.env.PUBLIC_URL;if(!mid||!pubUrl)throw new E(503,'درگاه پرداخت آنلاین هنوز فعال نشده است. فعلاً از کارت‌به‌کارت استفاده کنید.');
 const o=myOrder(r),remain=o.total-orderFull(o).paid;if(remain<=0)throw new E(409,'این سفارش کامل پرداخت شده است');
 const pid=Number(run("INSERT INTO payments(order_id,customer_id,amount,method) VALUES(?,?,?,'gateway')",o.id,o.customer_id,remain).lastInsertRowid);let j;
 try{const rs=await fetch(ZP()+'/pg/v4/payment/request.json',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},signal:AbortSignal.timeout(30000),body:JSON.stringify({merchant_id:mid,amount:remain*10,callback_url:pubUrl.replace(/\/$/,'')+'/api/pay/callback?pid='+pid,description:'سفارش '+o.code,metadata:{mobile:r.a.c.phone}})});j=await rs.json()}
 catch{run("UPDATE payments SET status='failed' WHERE id=?",pid);throw new E(502,'اتصال به درگاه برقرار نشد')}
 const au=j&&j.data&&j.data.authority;if(!au||j.data.code!==100){run("UPDATE payments SET status='failed' WHERE id=?",pid);throw new E(502,'درگاه درخواست را نپذیرفت')}
 run('UPDATE payments SET authority=? WHERE id=?',au,pid);return{url:(process.env.ZARINPAL_START||'https://www.zarinpal.com/pg/StartPay/')+au}});
R('GET','/api/pay/callback',null,async(r,b,res)=>{const mid=process.env.ZARINPAL_MERCHANT_ID,pid=Number(r.q.get('pid')),au=str(r.q.get('Authority'),60);res.redirect='/?pay=failed';
 const p=one("SELECT * FROM payments WHERE id=? AND method='gateway' AND authority=? AND status='pending'",pid,au);if(!p||!mid||r.q.get('Status')!=='OK'){if(p)run("UPDATE payments SET status='failed',updated_at=? WHERE id=?",now(),pid);return{}}
 try{const rs=await fetch(ZP()+'/pg/v4/payment/verify.json',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},signal:AbortSignal.timeout(30000),body:JSON.stringify({merchant_id:mid,amount:p.amount*10,authority:au})});const j=await rs.json();
  if(j&&j.data&&(j.data.code===100||j.data.code===101)){run("UPDATE payments SET status='paid',gateway_ref=?,updated_at=? WHERE id=?",String(j.data.ref_id||''),now(),pid);res.redirect='/?pay=ok'}else run("UPDATE payments SET status='failed',updated_at=? WHERE id=?",now(),pid)}catch{}return{}});
// تینا: استخراج اطلاعات فاکتور با Gemini (کلید فقط در متغیر محیطی سرور)
const PROMPT='This is a purchase invoice from a supplier. Extract the data and answer with JSON only, in this exact shape: {"seller":string|null,"date":"YYYY-MM-DD"|null,"rial":boolean,"items":[{"name":string|null,"qty":number|null,"unit_price":number|null,"line_total":number|null}]}. Use Latin digits. If any value is unreadable or missing use null; never guess. Convert Persian (Jalali) dates to Gregorian. Set rial=true if the amounts look like Rials rather than Tomans. Keep item names in their original language.';
const toks=n=>new Set(norm(n).split(/[\s\-_/،,.()]+/).filter(x=>x.length>1));
function suggest(name){const a=toks(name);if(!a.size)return null;let best=null,bs=0;for(const p of q('SELECT id,name FROM products')){const t=toks(p.name);if(!t.size)continue;let c=0;a.forEach(x=>{if(t.has(x))c++});const sc=c/Math.max(a.size,t.size);if(sc>bs){bs=sc;best=p.id}}return bs>=0.6?best:null}
R('POST','/api/admin/tina/extract','admin',async(r,b)=>{const key=process.env.GEMINI_API_KEY;if(!key)throw new E(503,'کلید GEMINI_API_KEY روی سرور تنظیم نشده است. تا آن زمان فاکتور را دستی وارد کنید.');
 if(limited('tina'))throw new E(429,'درخواست زیاد؛ کمی بعد دوباره امتحان کنید'); const text=str(b.text,6000),parts=[{text:PROMPT+(text?'\n\nInvoice text:\n'+text:'')}];
 if(b.image){const buf=Buffer.from(String(b.image.data||''),'base64');if(buf.length<100||buf.length>4*1024*1024||!sniff(buf))throw new E(400,'عکس فاکتور معتبر نیست (jpg/png/webp، حداکثر ۴ مگابایت)');
  parts.push({inline_data:{mime_type:'image/'+(sniff(buf)==='jpg'?'jpeg':sniff(buf)),data:buf.toString('base64')}})}
 if(!text&&!b.image)throw new E(400,'عکس یا متن فاکتور را وارد کنید');
 fail('tina');
 let out;try{const base=process.env.GEMINI_BASE||'https://generativelanguage.googleapis.com',model=process.env.GEMINI_MODEL||'gemini-2.0-flash';
  const rs=await fetch(`${base}/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},signal:AbortSignal.timeout(60000),body:JSON.stringify({contents:[{parts}],generationConfig:{responseMimeType:'application/json',temperature:0}})});
  if(!rs.ok)throw new Error('status '+rs.status);const j=await rs.json();const tx=String(j.candidates[0].content.parts.map(x=>x.text||'').join('')).trim(),mm=tx.match(/\{[\s\S]*\}/);out=JSON.parse(mm?mm[0]:tx);if(!out||typeof out!=='object')throw 0}
 catch(e){throw new E(502,'خواندن فاکتور انجام نشد؛ دوباره امتحان کنید یا دستی وارد کنید.')}
 const num=v=>{const n=Number(fd(v));return isFinite(n)&&n>0?Math.round(n):null};
 const rows=(Array.isArray(out.items)?out.items:[]).slice(0,100).map(i=>{const name=str(i&&i.name,150),qty=num(i&&i.qty);let up=num(i&&i.unit_price);if(!up&&qty&&num(i&&i.line_total))up=Math.round(num(i.line_total)/qty);
  return{name,qty,unit_price:up,needs_review:!name||!qty||!up,match_id:name?suggest(name):null}});
 const date=/^\d{4}-\d{2}-\d{2}$/.test(str(out.date,12))?out.date:null;
 return{seller:str(out.seller,100)||null,date,rial:!!out.rial,rows}});
// ثبت خرید پس از تأیید مدیر (ورودی از تینا یا دستی)
R('POST','/api/admin/invoices/confirm','admin',(r,b)=>{if(!Array.isArray(b.rows)||!b.rows.length)throw new E(400,'ردیفی وجود ندارد');const seller=str(b.seller,100),date=str(b.date,20),invImg=b.image?saveImage(b.image):'';
 const dOk=DATE_RE.test(date)?date:'';
 return tx(()=>{let total=0;const inv=Number(run('INSERT INTO purchase_invoices(seller,date,total,image) VALUES(?,?,0,?)',seller||null,dOk||null,invImg).lastInsertRowid);
  for(const x of b.rows){const name=str(x.name,150),qty=int(x.qty,1,1e6),up=int(x.unit_price,1);if(!name)throw new E(400,'نام کالا خالی است');let pid=x.product_id?int(x.product_id,1):null;
   if(pid){if(!one('SELECT 1 FROM products WHERE id=?',pid))throw new E(400,'محصول انتخاب‌شده وجود ندارد');run('UPDATE products SET stock=stock+?,buy_price=?,updated_at=? WHERE id=?',qty,up,now(),pid)}
   else{const m=x.margin_percent!==undefined?Number(fd(x.margin_percent)):null;const sell=m!==null&&isFinite(m)?Math.round(up*(1+m/100)/1000)*1000||up:up;
    pid=Number(run('INSERT INTO products(name,buy_price,sell_price,stock,active) VALUES(?,?,?,?,0)',name,up,sell,qty).lastInsertRowid)} // کالای جدید تا تأیید قیمت فروش غیرفعال است
   run('INSERT INTO purchase_invoice_items(invoice_id,product_id,name,qty,unit_price) VALUES(?,?,?,?,?)',inv,pid,name,qty,up);run('INSERT INTO product_sources(product_id,seller,date,qty,unit_price,source) VALUES(?,?,?,?,?,?)',pid,seller||null,dOk||null,qty,up,'invoice');total+=qty*up}
  run('UPDATE purchase_invoices SET total=? WHERE id=?',total,inv);return{invoice_id:inv,total}})});
// ---- سرور HTTP
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml'};
function body(req){return new Promise((ok,no)=>{let n=0,big=false;const a=[];req.on('data',c=>{n+=c.length;if(n>6e6)big=true;else a.push(c)});req.on('end',()=>{if(big)return no(new E(413,'حجم درخواست زیاد است'));try{ok(a.length?JSON.parse(Buffer.concat(a)):{})}catch{no(new E(400,'JSON نامعتبر'))}});})}
const SEC={'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'"};
function file(res,fp,cache){fs.readFile(fp,(e,d)=>{if(e){res.writeHead(404);return res.end('not found')}res.writeHead(200,{'Content-Type':MIME[path.extname(fp)]||'application/octet-stream',...SEC,'Cache-Control':cache});res.end(d)})}
const server=http.createServer(async(req,res)=>{const u=new URL(req.url,'http://x'),p=u.pathname;
 const send=(c,o,h={})=>{res.writeHead(c,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...SEC,...h});res.end(JSON.stringify(o))};
 try{if(p.startsWith('/api/')){const rt=routes.find(x=>x.m===req.method&&x.re.test(p));if(!rt)throw new E(404,'مسیر وجود ندارد');
  const r={ip:process.env.TRUST_PROXY==='0'?req.socket.remoteAddress:String(req.headers['x-forwarded-for']||req.socket.remoteAddress).split(',')[0].trim(),a:auth(req),p:(p.match(rt.re)||[]).slice(1),q:u.searchParams};
  if(rt.role==='admin'&&(!r.a||r.a.role!=='admin'))throw new E(r.a?403:401,'دسترسی ندارید');
  if(rt.role==='customer'&&(!r.a||r.a.role!=='customer'))throw new E(r.a?403:401,'ابتدا وارد شوید');
  if(rt.role==='any'&&!r.a)throw new E(401,'ابتدا وارد شوید');
  let b={};if(req.method!=='GET'){if(!/application\/json/.test(req.headers['content-type']||''))throw new E(415,'نوع درخواست نامعتبر');b=await body(req)}
  const out={};const data=await rt.fn(r,b,out);if(out.raw){res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename="${out.raw.name}"`,'Cache-Control':'no-store',...SEC});return res.end(out.raw.buf)}
  if(out.redirect){res.writeHead(302,{Location:out.redirect,'Cache-Control':'no-store'});return res.end()}return send(200,data,out.cookie?{'Set-Cookie':out.cookie}:{})}
  if(p.startsWith('/uploads/')){const f=path.basename(p);return file(res,path.join(DATA,'uploads',f),'public, max-age=31536000, immutable')}
  const fp=path.join(__dirname,'public',path.normalize(p==='/'?'/index.html':p).replace(/^(\.\.[\/\\])+/,''));
  if(!fp.startsWith(path.join(__dirname,'public')))throw new E(403,'ممنوع');
  fs.stat(fp,(e,s)=>file(res,e||!s.isFile()?path.join(__dirname,'public','index.html'):fp,'no-cache'))}
 catch(e){if(!(e instanceof E))console.error(e);send(e.code||500,{error:e instanceof E?e.message:'خطای داخلی سرور'})}});
if(require.main===module)server.listen(PORT,()=>console.log('http://localhost:'+PORT));
module.exports={server,db};
